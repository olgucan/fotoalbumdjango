<h1 align = 'center'>django-todolist</h1>
<p align="center">
  <a href="" rel="noopener">
 <img width=200px src="https://clickup.com/blog/wp-content/uploads/2019/01/to-do-list-apps-1400x1050.png" />
 </a>
</p>
<p align="center">
A simple todo list written in Python and Django by the best teacher on Youtube :)
</p>
